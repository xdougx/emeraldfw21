# This is an Emerald Framework application

As you may clearly see by its structure, it is a simple rack application and you may use it as such, adding as many rack middlewares as you like. For this reason I added [**rack-contrib gem**](https://rubygems.org/gems/rack-contrib) to its Gemfile.

Before you continue, let me tell you some important point about Emerald Framework and Emerald applications:

- **Emerald Framework is in alpha version**

Yes! This version you are using, whose codiname is 'Aragorn', is an alpha version.

To any sensible person, this means you shouldn't use it in a production environment by now.

But we are developers and developers are not sensible people! If we were sensible, we would have listened to our mothers and now we'd be medicine doctors, making huge money from easy things like opening someone's brain or taking someone's heart out of his/her chest!

But we are here, brushing bits and bytes 18 hours a day just for pleasure, and this tells a lot about the kind of people we are. So, do with this anything you like!

- **What is it for?** 

Emerald Framework was designed to create a nice, fast and funny environment for you to develop websites and web applications.

It will get better everyday, for many reasons. First of all, I believe we'll develop a strong community around it, and this community will grow a great software.

Second, because we'll be adding some wonderful features to it in a near feature. Can you imagine how easy will be to have, for instance, archetypes of applications, with all basic objects already created for you? And all this right in your command line? You need a blog application, then type

    emeraldfw create project myblog --archetype blog

and you have a basic blog in a matter of seconds! Easy as that!

Third, because integrating Emerald applications with libraries like **Ember.js**, **React.js** and many others is easy as pie!

(Those who use this expression, like me, never tried to make a good pie. It is not easy at all!)

We already have Emerald Framework packages for **jQuery** and **Bootstrap**, and we'll be publishing at least a new package every two days or so.

- **Freedom? What freedom?**

Emerald Framework is, of course, a framework!

(I'm telling you this just in case you haven't noticed it. And if you haven't noticed, consider the possibility of moving to something easier than programming. Like that brain surgery thing I mentioned above. You'll make your mother happy!)

A framework is a frame of reference to something. In this case, this 'something' is 'web development'. Then Emerald Framework creates criteria, and procedures to match these criteria, when developing a website or a web application.

You, of course, must comply with this criteria and use these procedures, if you want to use it. If you are one of those people who loves to do things your own way, don't even think about using a any framework. And specially don't even think about using Emerald Framework.

You'll not find 'freedom' here! What you'll find is a fast and easy way to create a website or a web application. 

So, having said all this, I let you with the pleasant task of building an Emerald application.

Ed de Almeida

emerald.framework@gmail.com

Skype: edalmeidajr