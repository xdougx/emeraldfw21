require 'spec_helper'

require 'rack'

require "emeraldfw"

require "#{spec_dir}/emerald"

describe EmeraldApp do

end