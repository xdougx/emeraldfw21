def spec_dir
  this_file = File.expand_path(__FILE__)
  path_array = this_file.split('/')
  "/#{path_array.slice(1,path_array.length-3).join('/')}"
end

def rspec_emerald_require(tp,file)
  "#{spec_dir}/api/code/#{tp}s/#{file}.rb"
end
