//////////////////////////////////////////////////////////////////
//                                                              //
// File: emerald.rb                                             //
// Author: Ed de Almeida (edvaldoajunior@gmail.com)             //
//                                                              //
// This file is an ESSENTIAL part of Emerald Frameword. It is   //
// Open Source and it is distributed under MIT License.         //
//                                                              //
//////////////////////////////////////////////////////////////////


var EMERALD = EMERALD || {};

EMERALD.version = "0.1.8"

EMERALD.stack = EMERALD.stack || {}

EMERALD.local_static = function(component_name,html_component_area,data) {

}

EMERALD.local_api = function(component_name,html_component_area,data) {

}

EMERALD.remote_static = function(component_name,html_component_area,data) {

}

EMERALD.remote_api = function(component_name,html_component_area,data) {

}

EMERALD.parse_code = function() {

	$(".emerald-component").each(function() {
		var myurl = nil
		var html_component_area = this
		var component_full_name = $(this).attr("name");
		var component_name = component_full_name.split(':')[1];
		EMERALD.stack[component_name] = html_component_area;
		// Loading component information
		$.ajax({
			url: "/info/component/"+component_name,
			success: function(data) {
				if data['remote'] {
					if data['api'] {
						EMERALD.remote_api(component_name,html_component_area,data);
					} else {
						EMERALD.remote_static(component_name,html_component_area,data);
					}
				} else {
					if data['api'] {
						EMERALD.local_static(component_name,html_component_area,data);
					} else {
						EMERALD.local_api(component_name,html_component_area,data);
					}
				}
			},
			error: function(data) {

			}
		});
	});

}
