require 'json'

class Example

  def a_method
  	{
  		:description => "This is an example of what a dynamic component should return. In this case it returns JSON to create a table.",
  		:header => ["Column 1", "Column 2", "Column 3"],
  		:data => [
  			["Value 1-1", "Value 1-2", "Value 1-3"],
  			["Value 2-1", "Value 2-2", "Value 2-3"],
  			["Value 3-1", "Value 3-2", "Value 3-3"],
  			["Value 4-1", "Value 4-2", "Value 4-3"],
  		]
   	}.to_json
  end

end
