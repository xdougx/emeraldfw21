##################################################################
#                                                                #
# File: emerald.rb                                               #
# Author: Ed de Almeida (edvaldoajunior@gmail.com)               #
#                                                                #
# This file is an ESSENTIAL part of Emerald Frameword. It is     #
# Open Source and it is distributed under MIT License, but we    #
# won't provide any support to Emerald Framework if you modify   #
# it anyway.                                                     #
#                                                                #
##################################################################

require "json"
require "httparty"
require "nokogiri"

require "emeraldfw"

## TODO: A loop to require all controllers enters here.
require "api/code/controllers/example.rb"

module Utils
  include EmeraldFW::Constants
  include EmeraldFW::ConfigFile

  def self.is_file?(str)
     str.include?('.')
  end

  def self.extension(str)
    str.split('.').last
  end  

  def self.get_file_parameters(req)
    ext = Utils.extension(req.path_info).to_sym
    path = "#{EmeraldFW::Constants::WEB_ASSETS_DIR}/#{ext}"
    fname = "#{path}#{req.path_info}"
    [ ext, path, fname ]    
  end

  def self.load_pages
    EmeraldFW::ConfigFile.json_content('pages')
  end 

  def self.load_templates
    EmeraldFW::ConfigFile.json_content('templates')
  end 

  def self.load_components
    EmeraldFW::ConfigFile.json_content('components')
  end 

  def self.load_config
    [ load_pages, load_templates, load_components ]
  end 

  def self.get_file(filename)
    File.read(filename)
  end

  def self.allowed_extension?(ext)
    File.exist?("#{EmeraldFW::Constants::WEB_ASSETS_DIR}/#{ext}")
  end

end

class EmeraldApp

  def call(env)
    req = Rack::Request.new(env)
    req.xhr? ? EmeraldAjaxProcessor.new.call(req) : EmeraldCommonProcessor.new.call(req)
  end

end

class EmeraldCommonProcessor

  def call(req)
    Utils.is_file?(req.path_info) ? EmeraldFileProcessor.new.call(req) : EmeraldPageProcessor.new.call(req)
  end

end

class EmeraldFileProcessor

  def call(req)
    ext, path, fname = Utils.get_file_parameters(req)
    if Utils.allowed_extension?(ext) then
      if File.exist?(fname) then
        file_content = Utils.get_file(fname)
        return [ 200, {"Content-Type" => EmeraldFW::Constants::MIME_TYPES[ext]}, [ file_content ] ]
      end
    end
    [ 404, {"Content-Type" => "text/html"}, [ "Resource not found. "] ]
  end

end

class EmeraldPageProcessor

  def call(req)
    req.path_info = "/index" if req.path_info == "/"
    req.path_info = "#{req.path_info}.html"
    ext, path, fname = [ "html", EmeraldFW::Constants::WEB_PAGES_DIR, "#{EmeraldFW::Constants::WEB_PAGES_DIR}#{req.path_info}"]
    File.exist?(fname) ? serve_page(req) : serve_error(404)
  end

  def serve_page(req)
    pages, templates, components = Utils.load_config
    page_name = req.path_info.split('.')[0]
    page_name = page_name.slice(1,(page_name.length-1))

    # Error if the page required is not registered at web/config/pages.json
    return [ 500, {"Content-Type" => "text/html"}, ["Page <strong>#{page_name}</strong> not registered!"] ] if pages[page_name].nil?

    # Template information
    template_name = pages[page_name]["template"]
    insertion_point_tag = pages[page_name]["insertion_point"]["tag"]
    insertion_point_id = pages[page_name]["insertion_point"]["id"] if not (insertion_point_tag == "body")
    template_file = "#{EmeraldFW::Constants::WEB_TEMPLATES_DIR}/#{template_name}.html"

    # Error if a non-existing template is required
    return [ 500, {"Content-Type" => "text/html"}, ["Template <strong>web/views/templates/#{template_name}.html</strong> does not exist!"] ] if not File.exist?(template_file)

    # Error if a non-existing page is required
    return [ 500, {"Content-Type" => "text/html"}, ["Page <strong>web/views/pages/#{page_name}.html</strong> does not exist!"] ] if not File.exist?(template_file)

    # Get the HTML contents of template and page
    html_template = Utils.get_file(template_file)
    html_page = Utils.get_file("#{EmeraldFW::Constants::WEB_PAGES_DIR}/#{page_name}.html")

    # Now use nokogiri to merge them
    doc = Nokogiri::HTML::Document.parse(html_template)

    if (insertion_point_tag == "body") then
      doc.search("body").first.inner_html = html_page
    else
      search = "#{insertion_point_tag}##{insertion_point_id}"
      doc.css(search).first.inner_html = html_page
    end

    [ 200, {"Content-Type" => "text/html"}, [ doc.to_html ] ]
  end


  def serve_error(error_number)
    [ 404, {"Content-Type" => "text/html"}, ["Page does not exist."] ]
  end

end

class EmeraldAjaxProcessor

  def call(req)
    req_resource = req.path_info
    @req_resource_arr = req_resource.split('/')
    @req_resource_arr.shift
    req_type = @req_resource_arr.shift.to_sym
    case req_type
    when :info
      info_request_processor
    when :local
      local_request_processor
    when :remote 
      remote_request_processor
    else
      return [ 404, { "Content-Type" => "text/html"}, ["Resource not found."] ]
    end
  end

  def info_request_processor
    req_entity = @req_resource_arr.shift.to_sym
    case req_entity
    when :component
      info_component_processor
    else 
      return [ 404, { "Content-Type" => "text/html"}, ["Resource not found."] ]
    end
  end

  def info_component_processor
    component_name = @req_resource_arr.shift
    component_info = EmeraldFW::CLI::Component.component_by_name(component_name).to_json
    response_header = Hash.new 
    response_header["Content-Type"] = "application/json"
    response_header["Content-Length"] = component_info.length.to_s
    [ 200, response_header, [component_info] ]    
  end  

  def local_request_processor
    req_type = @req_resource_arr.shift.to_sym
    case req_type
    when :static
      local_static_processor
    when :api
      local_api_processor
    end
  end

  def remote_request_processor
    req_type = @req_resource_arr.shift.to_sym
    case req_type
    when :static
      remote_static_processor
    when :api
      remote_api_processor
    end
  end

  def local_static_processor
    component_name = @req_resource_arr.last.split('.')[0]
    filename =  "#{@req_resource_arr.join('/')}"
    file = Utils.get_file(filename)
    result = { :component => component_name, :res => file}.to_json
    [ 200, {"Content-Type" => "application/json"}, [result]]
  end

  def local_api_processor
    component_name = @req_resource_arr.shift.to_sym
    controller_name = @req_resource_arr.shift.to_sym
    method_name = @req_resource_arr.shift.to_sym
    dynamic_data = Object.const_get(controller_name).method(method_name).call
    result = { :component => component_name, :res => dynamic_data.to_json }
    [ 200, {"Content-Type" => "application/json"}, [result]]
  end

  def remote_static_processor
    component_name = @req_resource_arr.shift
    component_url = @req_resource_arr.join('/')
    file = HTTParty.get(component_url)
    ## TODO: After this point it would be convenient to use Nokogiri to insert
    ##       a <base></base> tag in the header of the received file to make
    ##       all subsequent implicit requests based on it, not on the current domain.
    ##       It may also be necessary to adapt file requisitions to recorgnize
    ##       files in other domains.
    result = { :component => component_name, :file => file}.to_json
    [ 200, {"Content-Type" => "application/json"}, [result]]
  end

  def remote_api_processor

  end


end



